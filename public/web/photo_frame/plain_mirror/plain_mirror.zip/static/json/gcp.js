// var $item_price = "$" + Math.random().toFixed(4);
// var $item_price =  Math.random().toFixed(4);
//alert('hello');
var $item_price = 100;