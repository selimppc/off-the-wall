    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">108CR Float</span><span class="hide rebate">0.00</span><span class="hide width">1.5</span><span class="hide frate">4</span><span class="hide id">1275</span><span class="hide fmin">10</span><span class="hide fmax">160</span><span class="hide fimg">top_frame_1275.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1275.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 108CR Float
            <br><b>Color:</b> Lime Wash
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1275.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">108D Float</span><span class="hide rebate">0.00</span><span class="hide width">1.5</span><span class="hide frate">8</span><span class="hide id">860</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_860.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_860.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 108D Float
            <br><b>Color:</b> Mocha
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_860.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">108F Float</span><span class="hide rebate">0.00</span><span class="hide width">1.5</span><span class="hide frate">6</span><span class="hide id">609</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_609.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_609.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 108F Float
            <br><b>Color:</b> Black
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_609.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">108G Float</span><span class="hide rebate">0.00</span><span class="hide width">1.5</span><span class="hide frate">8</span><span class="hide id">607</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_607.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_607.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 108G Float
            <br><b>Color:</b> Black Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_607.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">108H Float</span><span class="hide rebate">0.00</span><span class="hide width">1.5</span><span class="hide frate">6</span><span class="hide id">610</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_610.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_610.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 108H Float
            <br><b>Color:</b> White
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_610.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">108L Float</span><span class="hide rebate">0.00</span><span class="hide width">1.5</span><span class="hide frate">8</span><span class="hide id">861</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_861.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_861.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 108L Float
            <br><b>Color:</b> Natural
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_861.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">108RW Float</span><span class="hide rebate">0.00</span><span class="hide width">1.5</span><span class="hide frate">8</span><span class="hide id">1276</span><span class="hide fmin">10</span><span class="hide fmax">160</span><span class="hide fimg">top_frame_1276.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1276.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 108RW Float
            <br><b>Color:</b> Natural Raw
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1276.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">108S Float</span><span class="hide rebate">0.00</span><span class="hide width">1.5</span><span class="hide frate">8</span><span class="hide id">608</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_608.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_608.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 108S Float
            <br><b>Color:</b> Black Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_608.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>*******************
    <p>*******************</p>