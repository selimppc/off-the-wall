<div class="frame" data-filtr="rate-1 code-220A" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">220A</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.4</span>
    <span class="hide frate">1</span>
    <span class="hide id">1227</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">61</span>
    <span class="hide fprice">50</span>
    <span class="hide fimg">top_frame_1227.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe" >
                <img data-src-top="images/frame_images/top_frame/top_frame_1227.jpg" border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1227.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <div class="name">
            <b>Code:</b> 220A
        </div>
        <br />
        <b>Color:</b> Light Stain

        <br />
        <b>Material:</b> Wood

        <br />
        <b>Width:</b> 1.4 cm

        <br />
        <b>Height:</b> 1.4 cm

        <br />
        <div class="rate">
            <b style="color: red;">Rate:</b> 1
        </div>
        <br />
        <br />
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1227.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-2 code-249L" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">249L</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.3</span>
    <span class="hide frate">2</span>
    <span class="hide id">928</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">70</span>
    <span class="hide fprice">40</span>
    <span class="hide fimg">top_frame_928.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe" >
                <img data-src-top="images/frame_images/top_frame/top_frame_928.jpg" border="0" alt="" src="images/frame_images/thumb/th_cross_frame_928.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <div class="name">
            <div class="code">
                <b>Code:</b> 249L
            </div>
        </div>
        <br />
        <b>Color:</b> Lacquered wood

        <br />
        <b>Material:</b> Wood

        <br />
        <b>Width:</b> 1.3 cm

        <br />
        <b>Height:</b> 1.5 cm

        <br />
        <div class="rate">
            <b style="color: red;">Rate:</b> 2
        </div>
        <br />
        <br />
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_928.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-3 code-220D" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">220D</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.4</span>
    <span class="hide frate">3</span>
    <span class="hide id">1228</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">61</span>
    <span class="hide fprice">120</span>
    <span class="hide fimg">top_frame_1228.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe" >
                <img data-src-top="images/frame_images/top_frame/top_frame_1228.jpg" border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1228.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <div class="name">
            <b>Code:</b> 220D
        </div>
        <br />
        <b>Color:</b> Mocha

        <br />
        <b>Material:</b> Wood

        <br />
        <b>Width:</b> 1.4 cm

        <br />
        <b>Height:</b> 1.4 cm

        <br />
        <div class="rate">
            <b style="color: red;">Rate:</b> 3
        </div>
        <br />
        <br />
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1228.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-4 code-220T" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">220T</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.4</span>
    <span class="hide frate">4</span>
    <span class="hide id">1300</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">61</span>
    <span class="hide fprice">140</span>
    <span class="hide fimg">top_frame_1300.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe" >
                <img data-src-top="images/frame_images/top_frame/top_frame_1300.jpg" border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1300.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <div class="name">
            <b>Code:</b> 220T
        </div>
        <br />
        <b>Color:</b> Teak

        <br />
        <b>Material:</b> Wood

        <br />
        <b>Width:</b> 1.4 cm

        <br />
        <b>Height:</b> 1.4 cm

        <br />
        <div class="rate">
            <b style="color: red;">Rate:</b> 4
        </div>
        <br />
        <br />
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1300.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-5 code-222A" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">222A</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.5</span>
    <span class="hide frate">5</span>
    <span class="hide id">743</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">62</span>
    <span class="hide fprice">170</span>
    <span class="hide fimg">top_frame_743.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe" >
                <img data-src-top="images/frame_images/top_frame/top_frame_743.jpg" border="0" alt="" src="images/frame_images/thumb/th_cross_frame_743.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <div class="name">
            <b>Code:</b> 222A
        </div>
        <br />
        <b>Color:</b> Honey

        <br />
        <b>Material:</b> Wood

        <br />
        <b>Width:</b> 1.5 cm

        <br />
        <b>Height:</b> 1.5 cm

        <br />
        <div class="rate">
            <b style="color: red;">Rate:</b> 5
        </div>
        <br />
        <br />
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_743.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-6 code-110BV" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">110BV</span>
    <span class="hide rebate">0.70</span>
    <span class="hide width">10</span>
    <span class="hide frate">6</span>
    <span class="hide id">1090</span>
    <span class="hide fmin">20</span>
    <span class="hide fmax">250</span>
    <span class="hide fprice">250</span>
    <span class="hide fimg">top_frame_1090.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe" >
                <img data-src-top="images/frame_images/top_frame/top_frame_1090.jpg" border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1090.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <div class="name">
            <b>Code:</b> 110BV
        </div>
        <br />
        <b>Color:</b> Bunya Veneer

        <br />
        <b>Material:</b> Wood

        <br />
        <b>Width:</b> 10 cm

        <br />
        <b>Height:</b> 2 cm

        <br />
        <div class="rate">
            <b style="color: red;">Rate:</b> 6
        </div>
        <br />
        <br />
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1090.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-7 code-110LV" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">110LV</span>
    <span class="hide rebate">0.70</span>
    <span class="hide width">10</span>
    <span class="hide frate">7</span>
    <span class="hide id">1089</span>
    <span class="hide fmin">20</span>
    <span class="hide fmax">250</span>
    <span class="hide fprice">320</span>
    <span class="hide fimg">top_frame_1089.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe" >
                <img data-src-top="images/frame_images/top_frame/top_frame_1089.jpg" border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1089.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <div class="name">
            <b>Code:</b> 110LV
        </div>
        <br />
        <b>Color:</b> Blond Veneer

        <br />
        <b>Material:</b> Wood

        <br />
        <b>Width:</b> 10 cm

        <br />
        <b>Height:</b> 2 cm

        <br />
        <div class="rate">
            <b style="color: red;">Rate:</b> 7
        </div>
        <br />
        <br />
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1089.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-8 code-110TV" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">110TV</span>
    <span class="hide rebate">0.70</span>
    <span class="hide width">10</span>
    <span class="hide frate">8</span>
    <span class="hide id">1092</span>
    <span class="hide fmin">20</span>
    <span class="hide fmax">250</span>
    <span class="hide fprice">900</span>
    <span class="hide fimg">top_frame_1092.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe" >
                <img data-src-top="images/frame_images/top_frame/top_frame_1092.jpg" border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1092.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <div class="name">
            <b>Code:</b> 110TV
        </div>
        <br />
        <b>Color:</b> Teak Veneer

        <br />
        <b>Material:</b> Wood

        <br />
        <b>Width:</b> 10 cm

        <br />
        <b>Height:</b> 2 cm

        <br />
        <div class="rate">
            <b style="color: red;">Rate:</b> 8
        </div>
        <br />
        <br />
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1092.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-10 code-110CH" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">110CH</span>
    <span class="hide rebate">0.70</span>
    <span class="hide width">10</span>
    <span class="hide frate">10</span>
    <span class="hide id">1150</span>
    <span class="hide fmin">9</span>
    <span class="hide fmax">250</span>
    <span class="hide fprice">225</span>
    <span class="hide fimg">top_frame_1150.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe" >
                <img data-src-top="images/frame_images/top_frame/top_frame_1150.jpg" border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1150.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <div class="name">
            <b>Code:</b> 110CH
        </div>
        <br />
        <b>Color:</b> Fence Charc

        <br />
        <b>Material:</b> Wood

        <br />
        <b>Width:</b> 10 cm

        <br />
        <b>Height:</b> 2 cm

        <br />
        <div class="rate">
            <b style="color: red;">Rate:</b> 10
        </div>
        <br />
        <br />
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1150.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-1 code-412RT" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">412RT</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">3.5</span>
    <span class="hide frate">1</span>
    <span class="hide id">1314</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">200</span>
    <span class="hide fprice">550</span>
    <span class="hide fimg">top_frame_1314.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe" >
                <img data-src-top="images/frame_images/top_frame/top_frame_1314.jpg" border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1314.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <b>Code:</b> 412RT

        <br />
        <b>Color:</b> Rust

        <br />
        <b>Material:</b> Wood

        <br />
        <b>Width:</b> 3.5 cm

        <br />
        <b>Height:</b> 4.75 cm

        <br />
        <b style="color: red;">Rate:</b> 1

        <br />
        <br />
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1314.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-2 code-136B" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">136B</span>
    <span class="hide rebate">0.40</span>
    <span class="hide width">3.75</span>
    <span class="hide frate">2</span>
    <span class="hide id">178</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">200</span>
    <span class="hide fprice">600</span>
    <span class="hide fimg">top_frame_178.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe" >
                <img data-src-top="images/frame_images/top_frame/top_frame_178.jpg" border="0" alt="" src="images/frame_images/thumb/th_cross_frame_178.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <b>Code:</b> 136B

        <br />
        <b>Color:</b> Walnut Gold

        <br />
        <b>Material:</b> Wood

        <br />
        <b>Width:</b> 3.75 cm

        <br />
        <b>Height:</b> 2 cm

        <br />
        <b style="color: red;">Rate:</b> 2

        <br />
        <br />
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_178.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>