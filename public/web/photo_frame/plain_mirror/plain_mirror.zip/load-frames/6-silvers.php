    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">AL7Silver</span><span class="hide rebate">0.70</span><span class="hide width">1</span><span class="hide frate">5</span><span class="hide id">1268</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_1268.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1268.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> AL7Silver
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Aluminium
            <br>
            <b>Width:</b> 1 cm
            <br>
            <b>Height:</b> 1 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1268.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">1202S</span><span class="hide rebate">0.50</span><span class="hide width">1.5</span><span class="hide frate">3</span><span class="hide id">1337</span><span class="hide fmin">10</span><span class="hide fmax">70</span><span class="hide fimg">top_frame_1337.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1337.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 1202S
            <br><b>Color:</b> Antique Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.5 cm
            <br>
            <b>Height:</b> 1.75 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1337.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">1203S</span><span class="hide rebate">0.50</span><span class="hide width">1.75</span><span class="hide frate">4</span><span class="hide id">1336</span><span class="hide fmin">10</span><span class="hide fmax">70</span><span class="hide fimg">top_frame_1336.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1336.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 1203S
            <br><b>Color:</b> Antique Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.75 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1336.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">414S</span><span class="hide rebate">0.50</span><span class="hide width">1.75</span><span class="hide frate">4</span><span class="hide id">1339</span><span class="hide fmin">10</span><span class="hide fmax">70</span><span class="hide fimg">top_frame_1339.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1339.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 414S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.75 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1339.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">155S</span><span class="hide rebate">0.50</span><span class="hide width">2</span><span class="hide frate">4</span><span class="hide id">1407</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_1407.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1407.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 155S
            <br><b>Color:</b> Silver/Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1407.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">217S</span><span class="hide rebate">0.50</span><span class="hide width">2</span><span class="hide frate">4</span><span class="hide id">1389</span><span class="hide fmin">10</span><span class="hide fmax">102</span><span class="hide fimg">top_frame_1389.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1389.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 217S
            <br><b>Color:</b> Champagne aged
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1389.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">221S</span><span class="hide rebate">0.50</span><span class="hide width">2</span><span class="hide frate">4</span><span class="hide id">631</span><span class="hide fmin">10</span><span class="hide fmax">120</span><span class="hide fimg">top_frame_631.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_631.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 221S
            <br><b>Color:</b> Silver Champ
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_631.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">224CS</span><span class="hide rebate">0.40</span><span class="hide width">2</span><span class="hide frate">3</span><span class="hide id">645</span><span class="hide fmin">10</span><span class="hide fmax">101</span><span class="hide fimg">top_frame_645.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_645.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 224CS
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_645.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">224S</span><span class="hide rebate">0.40</span><span class="hide width">2</span><span class="hide frate">3</span><span class="hide id">75</span><span class="hide fmin">10</span><span class="hide fmax">101</span><span class="hide fimg">top_frame_75.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_75.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 224S
            <br><b>Color:</b> Scratch Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_75.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">103S</span><span class="hide rebate">0.40</span><span class="hide width">2.1</span><span class="hide frate">5</span><span class="hide id">421</span><span class="hide fmin">10</span><span class="hide fmax">160</span><span class="hide fimg">top_frame_421.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_421.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 103S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.1 cm
            <br>
            <b>Height:</b> 3.8 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_421.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">103SS</span><span class="hide rebate">0.50</span><span class="hide width">2.1</span><span class="hide frate">5</span><span class="hide id">863</span><span class="hide fmin">10</span><span class="hide fmax">160</span><span class="hide fimg">top_frame_863.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_863.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 103SS
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.1 cm
            <br>
            <b>Height:</b> 3.8 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_863.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">156BS</span><span class="hide rebate">0.50</span><span class="hide width">2.25</span><span class="hide frate">4</span><span class="hide id">1385</span><span class="hide fmin">10</span><span class="hide fmax">102</span><span class="hide fimg">top_frame_1385.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1385.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 156BS
            <br><b>Color:</b> Bronze and Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.25 cm
            <br>
            <b>Height:</b> 2.25 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1385.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">156DS</span><span class="hide rebate">0.50</span><span class="hide width">2.25</span><span class="hide frate">4</span><span class="hide id">1384</span><span class="hide fmin">10</span><span class="hide fmax">102</span><span class="hide fimg">top_frame_1384.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1384.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 156DS
            <br><b>Color:</b> Brown with Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.25 cm
            <br>
            <b>Height:</b> 2.25 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1384.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">227S</span><span class="hide rebate">0.40</span><span class="hide width">2.25</span><span class="hide frate">2</span><span class="hide id">232</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_232.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_232.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 227S
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.25 cm
            <br>
            <b>Height:</b> 1.5 cm
            <br>
            <b style="color: red;">Rate:</b> 2
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_232.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">420S</span><span class="hide rebate">0.50</span><span class="hide width">2.25</span><span class="hide frate">4</span><span class="hide id">1387</span><span class="hide fmin">10</span><span class="hide fmax">102</span><span class="hide fimg">top_frame_1387.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1387.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 420S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.25 cm
            <br>
            <b>Height:</b> 2.25 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1387.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">145S</span><span class="hide rebate">0.50</span><span class="hide width">2.5</span><span class="hide frate">5</span><span class="hide id">874</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_874.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_874.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 145S
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.5 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_874.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">202S</span><span class="hide rebate">0.40</span><span class="hide width">2.5</span><span class="hide frate">6</span><span class="hide id">490</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_490.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_490.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 202S
            <br><b>Color:</b> Ornate Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.5 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_490.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">214S</span><span class="hide rebate">0.50</span><span class="hide width">2.5</span><span class="hide frate">4</span><span class="hide id">1382</span><span class="hide fmin">10</span><span class="hide fmax">92</span><span class="hide fimg">top_frame_1382.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1382.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 214S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1382.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">424S</span><span class="hide rebate">0.50</span><span class="hide width">2.5</span><span class="hide frate">4</span><span class="hide id">1379</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1379.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1379.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 424S
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.5 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1379.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">426S</span><span class="hide rebate">0.50</span><span class="hide width">2.5</span><span class="hide frate">3</span><span class="hide id">1395</span><span class="hide fmin">10</span><span class="hide fmax">102</span><span class="hide fimg">top_frame_1395.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1395.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 426S
            <br><b>Color:</b> Silver Champagne Ornate
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.5 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1395.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">684P</span><span class="hide rebate">0.50</span><span class="hide width">2.75</span><span class="hide frate">8</span><span class="hide id">1208</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1208.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1208.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 684P
            <br><b>Color:</b> Silver Charcoal
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.75 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1208.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">684S</span><span class="hide rebate">0.50</span><span class="hide width">2.75</span><span class="hide frate">8</span><span class="hide id">1207</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1207.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1207.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 684S
            <br><b>Color:</b> Silver Washed-Black
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.75 cm
            <br>
            <b>Height:</b> 2.25 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1207.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">195S</span><span class="hide rebate">0.50</span><span class="hide width">3</span><span class="hide frate">4</span><span class="hide id">1318</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_1318.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1318.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 195S
            <br><b>Color:</b> Antique Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1318.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">232S</span><span class="hide rebate">0.40</span><span class="hide width">3</span><span class="hide frate">4</span><span class="hide id">48</span><span class="hide fmin">10</span><span class="hide fmax">160</span><span class="hide fimg">top_frame_48.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_48.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 232S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_48.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">232SS</span><span class="hide rebate">0.50</span><span class="hide width">3</span><span class="hide frate">4</span><span class="hide id">911</span><span class="hide fmin">10</span><span class="hide fmax">160</span><span class="hide fimg">top_frame_911.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_911.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 232SS
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_911.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">270PS</span><span class="hide rebate">0.40</span><span class="hide width">3</span><span class="hide frate">1</span><span class="hide id">587</span><span class="hide fmin">10</span><span class="hide fmax">61</span><span class="hide fimg">top_frame_587.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_587.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 270PS
            <br><b>Color:</b> Pewter
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 1.6 cm
            <br>
            <b style="color: red;">Rate:</b> 1
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_587.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">270SS</span><span class="hide rebate">0.40</span><span class="hide width">3</span><span class="hide frate">1</span><span class="hide id">581</span><span class="hide fmin">10</span><span class="hide fmax">61</span><span class="hide fimg">top_frame_581.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_581.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 270SS
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Synthetic
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 1.6 cm
            <br>
            <b style="color: red;">Rate:</b> 1
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_581.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">285S</span><span class="hide rebate">0.40</span><span class="hide width">3</span><span class="hide frate">2</span><span class="hide id">100</span><span class="hide fmin">10</span><span class="hide fmax">80</span><span class="hide fimg">top_frame_100.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_100.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 285S
            <br><b>Color:</b> Silverish
            <br><b>Material:</b> Synthetic
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 2
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_100.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">423S</span><span class="hide rebate">0.50</span><span class="hide width">3</span><span class="hide frate">6</span><span class="hide id">1378</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1378.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1378.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 423S
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1378.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">624S</span><span class="hide rebate">0.40</span><span class="hide width">3</span><span class="hide frate">4</span><span class="hide id">197</span><span class="hide fmin">10</span><span class="hide fmax">120</span><span class="hide fimg">top_frame_197.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_197.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 624S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_197.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">203S</span><span class="hide rebate">0.50</span><span class="hide width">3.25</span><span class="hide frate">4</span><span class="hide id">1046</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_1046.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1046.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 203S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Synthetic
            <br>
            <b>Width:</b> 3.25 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1046.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">244S</span><span class="hide rebate">0.50</span><span class="hide width">3.25</span><span class="hide frate">8</span><span class="hide id">1301</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1301.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1301.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 244S
            <br><b>Color:</b> Black and Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3.25 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1301.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">268DS</span><span class="hide rebate">0.50</span><span class="hide width">3.5</span><span class="hide frate">1</span><span class="hide id">930</span><span class="hide fmin">10</span><span class="hide fmax">80</span><span class="hide fimg">top_frame_930.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_930.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 268DS
            <br><b>Color:</b> Dark Mocha Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 3.5 cm
            <br>
            <b>Height:</b> 1.5 cm
            <br>
            <b style="color: red;">Rate:</b> 1
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_930.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">268S</span><span class="hide rebate">0.50</span><span class="hide width">3.5</span><span class="hide frate">1</span><span class="hide id">763</span><span class="hide fmin">10</span><span class="hide fmax">80</span><span class="hide fimg">top_frame_763.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_763.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 268S
            <br><b>Color:</b> Scratch Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 3.5 cm
            <br>
            <b>Height:</b> 1.5 cm
            <br>
            <b style="color: red;">Rate:</b> 1
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_763.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">405S</span><span class="hide rebate">0.50</span><span class="hide width">3.5</span><span class="hide frate">5</span><span class="hide id">1325</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1325.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1325.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 405S
            <br><b>Color:</b> Pewtry Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3.5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1325.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">235FS</span><span class="hide rebate">0.70</span><span class="hide width">4</span><span class="hide frate">4</span><span class="hide id">1030</span><span class="hide fmin">10</span><span class="hide fmax">80</span><span class="hide fimg">top_frame_1030.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1030.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 235FS
            <br><b>Color:</b> Black Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 4 cm
            <br>
            <b>Height:</b> 2.8 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1030.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">235S</span><span class="hide rebate">0.70</span><span class="hide width">4</span><span class="hide frate">4</span><span class="hide id">1031</span><span class="hide fmin">10</span><span class="hide fmax">80</span><span class="hide fimg">top_frame_1031.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1031.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 235S
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 4 cm
            <br>
            <b>Height:</b> 2.8 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1031.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">408S</span><span class="hide rebate">0.50</span><span class="hide width">4</span><span class="hide frate">8</span><span class="hide id">1345</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1345.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1345.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 408S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1345.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">422S</span><span class="hide rebate">0.50</span><span class="hide width">4</span><span class="hide frate">6</span><span class="hide id">1377</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1377.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1377.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 422S
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1377.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">166S</span><span class="hide rebate">0.50</span><span class="hide width">4.25</span><span class="hide frate">6</span><span class="hide id">1330</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1330.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1330.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 166S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.25 cm
            <br>
            <b>Height:</b> 2.6 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1330.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">171SS</span><span class="hide rebate">0.40</span><span class="hide width">4.25</span><span class="hide frate">5</span><span class="hide id">621</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_621.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_621.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 171SS
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.25 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_621.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">200P</span><span class="hide rebate">0.50</span><span class="hide width">4.25</span><span class="hide frate">6</span><span class="hide id">1020</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_1020.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1020.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 200P
            <br><b>Color:</b> Bronze Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.25 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1020.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">200S</span><span class="hide rebate">0.50</span><span class="hide width">4.25</span><span class="hide frate">6</span><span class="hide id">1019</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_1019.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1019.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 200S
            <br><b>Color:</b> Pewter Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.25 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1019.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">179S</span><span class="hide rebate">0.50</span><span class="hide width">4.5</span><span class="hide frate">8</span><span class="hide id">718</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_718.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_718.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 179S
            <br><b>Color:</b> Antique Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_718.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">230S</span><span class="hide rebate">0.50</span><span class="hide width">4.5</span><span class="hide frate">7</span><span class="hide id">908</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_908.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_908.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 230S
            <br><b>Color:</b> Silver Black
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 2.2 cm
            <br>
            <b style="color: red;">Rate:</b> 7
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_908.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">231S</span><span class="hide rebate">0.40</span><span class="hide width">4.5</span><span class="hide frate">5</span><span class="hide id">278</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_278.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_278.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 231S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 2.2 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_278.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">231SS</span><span class="hide rebate">0.50</span><span class="hide width">4.5</span><span class="hide frate">5</span><span class="hide id">905</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_905.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_905.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 231SS
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 2.2 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_905.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">277SS</span><span class="hide rebate">0.40</span><span class="hide width">4.5</span><span class="hide frate">2</span><span class="hide id">598</span><span class="hide fmin">10</span><span class="hide fmax">115</span><span class="hide fimg">top_frame_598.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_598.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 277SS
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 1.7 cm
            <br>
            <b style="color: red;">Rate:</b> 2
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_598.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">280P</span><span class="hide rebate">0.50</span><span class="hide width">4.5</span><span class="hide frate">3</span><span class="hide id">1142</span><span class="hide fmin">9</span><span class="hide fmax">120</span><span class="hide fimg">top_frame_1142.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1142.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 280P
            <br><b>Color:</b> Pewter
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1142.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">623S</span><span class="hide rebate">0.50</span><span class="hide width">4.5</span><span class="hide frate">5</span><span class="hide id">664</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_664.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_664.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 623S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 2.2 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_664.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">685P</span><span class="hide rebate">0.00</span><span class="hide width">4.5</span><span class="hide frate">12</span><span class="hide id">1209</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1209.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1209.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 685P
            <br><b>Color:</b> Black Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 3.25 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1209.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">685S</span><span class="hide rebate">0.50</span><span class="hide width">4.5</span><span class="hide frate">12</span><span class="hide id">1206</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1206.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1206.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 685S
            <br><b>Color:</b> Silver Washed-Black
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 3.25 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1206.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">351S</span><span class="hide rebate">1.00</span><span class="hide width">4.75</span><span class="hide frate">8</span><span class="hide id">746</span><span class="hide fmin">10</span><span class="hide fmax">260</span><span class="hide fimg">top_frame_746.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_746.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 351S
            <br><b>Color:</b> Brushed Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.75 cm
            <br>
            <b>Height:</b> 4.75 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_746.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">215S</span><span class="hide rebate">0.40</span><span class="hide width">5</span><span class="hide frate">3</span><span class="hide id">144</span><span class="hide fmin">10</span><span class="hide fmax">120</span><span class="hide fimg">top_frame_144.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_144.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 215S
            <br><b>Color:</b> Ornate Champagne
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 5 cm
            <br>
            <b>Height:</b> 3.4 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_144.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">263S</span><span class="hide rebate">0.40</span><span class="hide width">5</span><span class="hide frate">3</span><span class="hide id">35</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_35.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_35.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 263S
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_35.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">324S</span><span class="hide rebate">0.50</span><span class="hide width">5</span><span class="hide frate">6</span><span class="hide id">1359</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1359.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1359.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 324S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 5 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1359.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">582SS</span><span class="hide rebate">0.40</span><span class="hide width">5</span><span class="hide frate">20</span><span class="hide id">514</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_514.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_514.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 582SS
            <br><b>Color:</b> Stainless Steel
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 5 cm
            <br>
            <b>Height:</b> 4.5 cm
            <br>
            <b style="color: red;">Rate:</b> 20
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_514.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">516S</span><span class="hide rebate">0.50</span><span class="hide width">5.25</span><span class="hide frate">3</span><span class="hide id">829</span><span class="hide fmin">10</span><span class="hide fmax">120</span><span class="hide fimg">top_frame_829.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_829.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 516S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 5.25 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_829.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">549S</span><span class="hide rebate">0.50</span><span class="hide width">5.5</span><span class="hide frate">7</span><span class="hide id">1075</span><span class="hide fmin">9</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1075.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1075.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 549S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 5.5 cm
            <br>
            <b>Height:</b> 4.5 cm
            <br>
            <b style="color: red;">Rate:</b> 7
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1075.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">627S</span><span class="hide rebate">0.40</span><span class="hide width">5.5</span><span class="hide frate">12</span><span class="hide id">486</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_486.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_486.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 627S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 5.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_486.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">682S</span><span class="hide rebate">0.50</span><span class="hide width">5.5</span><span class="hide frate">8</span><span class="hide id">998</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_998.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_998.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 682S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 5.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_998.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">102C</span><span class="hide rebate">0.50</span><span class="hide width">6</span><span class="hide frate">6</span><span class="hide id">1341</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_1341.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1341.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 102C
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1341.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">102S</span><span class="hide rebate">0.40</span><span class="hide width">6</span><span class="hide frate">6</span><span class="hide id">222</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_222.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_222.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 102S
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_222.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">278P</span><span class="hide rebate">0.50</span><span class="hide width">6</span><span class="hide frate">3</span><span class="hide id">815</span><span class="hide fmin">10</span><span class="hide fmax">120</span><span class="hide fimg">top_frame_815.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_815.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 278P
            <br><b>Color:</b> Pewter
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 6 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_815.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">278S</span><span class="hide rebate">0.50</span><span class="hide width">6</span><span class="hide frate">3</span><span class="hide id">818</span><span class="hide fmin">10</span><span class="hide fmax">120</span><span class="hide fimg">top_frame_818.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_818.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 278S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 6 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_818.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">606P</span><span class="hide rebate">0.50</span><span class="hide width">6</span><span class="hide frate">3</span><span class="hide id">1346</span><span class="hide fmin">10</span><span class="hide fmax">95</span><span class="hide fimg">top_frame_1346.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1346.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 606P
            <br><b>Color:</b> Silver-Puter
            <br><b>Material:</b> Synthetic
            <br>
            <b>Width:</b> 6 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1346.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">513S</span><span class="hide rebate">0.50</span><span class="hide width">6.25</span><span class="hide frate">16</span><span class="hide id">810</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_810.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_810.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 513S
            <br><b>Color:</b> Silver Leaf
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6.25 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 16
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_810.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">116S</span><span class="hide rebate">0.50</span><span class="hide width">6.5</span><span class="hide frate">6</span><span class="hide id">865</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_865.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_865.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 116S
            <br><b>Color:</b> Antique Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6.5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_865.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">421S</span><span class="hide rebate">0.50</span><span class="hide width">6.5</span><span class="hide frate">10</span><span class="hide id">1376</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1376.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1376.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 421S
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6.5 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 10
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1376.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">642S</span><span class="hide rebate">0.40</span><span class="hide width">6.5</span><span class="hide frate">8</span><span class="hide id">113</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_113.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_113.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 642S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6.5 cm
            <br>
            <b>Height:</b> 2.8 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_113.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">645S</span><span class="hide rebate">0.50</span><span class="hide width">6.5</span><span class="hide frate">9</span><span class="hide id">1130</span><span class="hide fmin">9</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1130.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1130.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 645S
            <br><b>Color:</b> Silver Shiny
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6.5 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 9
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1130.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">683S</span><span class="hide rebate">0.50</span><span class="hide width">6.5</span><span class="hide frate">4</span><span class="hide id">1016</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1016.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1016.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 683S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 6.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1016.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">902S</span><span class="hide rebate">0.50</span><span class="hide width">6.5</span><span class="hide frate">10</span><span class="hide id">1343</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1343.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1343.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 902S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6.5 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 10
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1343.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">661S</span><span class="hide rebate">0.40</span><span class="hide width">6.75</span><span class="hide frate">5</span><span class="hide id">41</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_41.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_41.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 661S
            <br><b>Color:</b> Antique Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 6.75 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_41.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">239SS</span><span class="hide rebate">0.50</span><span class="hide width">7</span><span class="hide frate">8</span><span class="hide id">1352</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1352.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1352.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 239SS
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 7 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1352.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">543CH</span><span class="hide rebate">0.50</span><span class="hide width">7</span><span class="hide frate">12</span><span class="hide id">1056</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1056.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1056.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 543CH
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 7 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1056.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">543S</span><span class="hide rebate">0.50</span><span class="hide width">7</span><span class="hide frate">12</span><span class="hide id">1057</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1057.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1057.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 543S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 7 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1057.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">560s</span><span class="hide rebate">0.50</span><span class="hide width">7</span><span class="hide frate">12</span><span class="hide id">1321</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1321.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1321.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 560s
            <br><b>Color:</b> Silver - Black Wash
            <br><b>Material:</b> Aluminium
            <br>
            <b>Width:</b> 7 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1321.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">653S</span><span class="hide rebate">0.40</span><span class="hide width">7</span><span class="hide frate">4</span><span class="hide id">562</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_562.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_562.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 653S
            <br><b>Color:</b> Antique Dark Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 7 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_562.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">658S</span><span class="hide rebate">0.50</span><span class="hide width">7</span><span class="hide frate">5</span><span class="hide id">761</span><span class="hide fmin">10</span><span class="hide fmax">130</span><span class="hide fimg">top_frame_761.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_761.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 658S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 7 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_761.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">539S</span><span class="hide rebate">0.50</span><span class="hide width">7.5</span><span class="hide frate">13</span><span class="hide id">1223</span><span class="hide fmin">10</span><span class="hide fmax">240</span><span class="hide fimg">top_frame_1223.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1223.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 539S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 7.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 13
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1223.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">587S</span><span class="hide rebate">0.40</span><span class="hide width">7.5</span><span class="hide frate">5</span><span class="hide id">23</span><span class="hide fmin">10</span><span class="hide fmax">130</span><span class="hide fimg">top_frame_23.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_23.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 587S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 7.5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_23.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">521S</span><span class="hide rebate">0.50</span><span class="hide width">8</span><span class="hide frate">16</span><span class="hide id">992</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_992.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_992.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 521S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 8 cm
            <br>
            <b>Height:</b> 4.5 cm
            <br>
            <b style="color: red;">Rate:</b> 16
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_992.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">556S</span><span class="hide rebate">0.50</span><span class="hide width">8</span><span class="hide frate">13</span><span class="hide id">1129</span><span class="hide fmin">9</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_1129.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1129.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 556S
            <br><b>Color:</b> Silve Ornate
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 8 cm
            <br>
            <b>Height:</b> 4 cm
            <br>
            <b style="color: red;">Rate:</b> 13
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1129.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">570S</span><span class="hide rebate">0.50</span><span class="hide width">8</span><span class="hide frate">8</span><span class="hide id">465</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_465.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_465.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 570S
            <br><b>Color:</b> Antique Champagne
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 8 cm
            <br>
            <b>Height:</b> 5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_465.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">571S</span><span class="hide rebate">0.50</span><span class="hide width">8</span><span class="hide frate">7</span><span class="hide id">1355</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1355.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1355.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 571S
            <br><b>Color:</b> Pewter &amp; Black
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 8 cm
            <br>
            <b>Height:</b> 5 cm
            <br>
            <b style="color: red;">Rate:</b> 7
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1355.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">586S</span><span class="hide rebate">0.40</span><span class="hide width">8</span><span class="hide frate">5</span><span class="hide id">449</span><span class="hide fmin">10</span><span class="hide fmax">153</span><span class="hide fimg">top_frame_449.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_449.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 586S
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 8 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_449.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">532S</span><span class="hide rebate">0.50</span><span class="hide width">8.5</span><span class="hide frate">6</span><span class="hide id">1138</span><span class="hide fmin">9</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1138.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1138.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 532S
            <br><b>Color:</b> Silver antique
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 8.5 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1138.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">109S</span><span class="hide rebate">0.50</span><span class="hide width">9</span><span class="hide frate">6</span><span class="hide id">702</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_702.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_702.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 109S
            <br><b>Color:</b> Silver Black
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 9 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_702.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">110P</span><span class="hide rebate">0.50</span><span class="hide width">9</span><span class="hide frate">15</span><span class="hide id">1313</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1313.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1313.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 110P
            <br><b>Color:</b> Silver - Pewter
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 9 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 15
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1313.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">110S</span><span class="hide rebate">0.50</span><span class="hide width">9</span><span class="hide frate">12</span><span class="hide id">698</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_698.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_698.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 110S
            <br><b>Color:</b> Brush Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 9 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_698.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">507S</span><span class="hide rebate">0.40</span><span class="hide width">9</span><span class="hide frate">15</span><span class="hide id">624</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_624.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_624.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 507S
            <br><b>Color:</b> BronzeSilver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 9 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 15
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_624.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">544S</span><span class="hide rebate">0.50</span><span class="hide width">9</span><span class="hide frate">12</span><span class="hide id">1055</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1055.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1055.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 544S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 9 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1055.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">632S</span><span class="hide rebate">0.50</span><span class="hide width">9</span><span class="hide frate">7</span><span class="hide id">1069</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1069.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1069.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 632S
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 9 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 7
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1069.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">541S</span><span class="hide rebate">0.40</span><span class="hide width">9.5</span><span class="hide frate">6</span><span class="hide id">506</span><span class="hide fmin">10</span><span class="hide fmax">130</span><span class="hide fimg">top_frame_506.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_506.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 541S
            <br><b>Color:</b> pewter
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 9.5 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_506.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">510S</span><span class="hide rebate">0.50</span><span class="hide width">10</span><span class="hide frate">10</span><span class="hide id">978</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_978.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_978.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 510S
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 10 cm
            <br>
            <b>Height:</b> 4 cm
            <br>
            <b style="color: red;">Rate:</b> 10
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_978.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">540S-539S</span><span class="hide rebate">0.50</span><span class="hide width">10</span><span class="hide frate">20</span><span class="hide id">1058</span><span class="hide fmin">25</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_1058.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1058.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 540S-539S
            <br><b>Color:</b> Double Frame
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 10 cm
            <br>
            <b>Height:</b> 7.5 cm
            <br>
            <b style="color: red;">Rate:</b> 20
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1058.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">542S</span><span class="hide rebate">0.50</span><span class="hide width">10</span><span class="hide frate">8</span><span class="hide id">1054</span><span class="hide fmin">25</span><span class="hide fmax">240</span><span class="hide fimg">top_frame_1054.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1054.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 542S
            <br><b>Color:</b> Silver Antique
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 10 cm
            <br>
            <b>Height:</b> 5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1054.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">545S</span><span class="hide rebate">0.40</span><span class="hide width">10</span><span class="hide frate">14</span><span class="hide id">646</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_646.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_646.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 545S
            <br><b>Color:</b> Antique Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 10 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 14
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_646.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">528S</span><span class="hide rebate">1.00</span><span class="hide width">11</span><span class="hide frate">12</span><span class="hide id">478</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_478.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_478.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 528S
            <br><b>Color:</b> Antique Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 11 cm
            <br>
            <b>Height:</b> 4.5 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_478.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">531S</span><span class="hide rebate">0.50</span><span class="hide width">11</span><span class="hide frate">12</span><span class="hide id">1152</span><span class="hide fmin">9</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1152.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1152.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 531S
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 11 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1152.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">598S</span><span class="hide rebate">0.40</span><span class="hide width">13</span><span class="hide frate">20</span><span class="hide id">391</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_391.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_391.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 598S
            <br><b>Color:</b> Antique Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 13 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 20
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_391.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>*******************
    <p>*******************</p>