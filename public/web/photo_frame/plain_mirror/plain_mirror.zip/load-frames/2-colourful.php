<div class="frame" data-filtr="rate-3 code-130CO" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">130CO</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.5</span>
    <span class="hide frate">3</span>
    <span class="hide id">1263</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">61</span>
    <span class="hide fimg">top_frame_1263.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe">
                <img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1263.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <b>Code:</b> 130CO
        <br>
        <b>Color:</b> Cream
        <br>
        <b>Material:</b> Wood
        <br>
        <b>Width:</b> 1.5 cm
        <br>
        <b>Height:</b> 2 cm
        <br>
        <b style="color: red;">Rate:</b> 3
        <br>
        <br>
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1263.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-2 code-130DO" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">130DO</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.5</span>
    <span class="hide frate">2</span>
    <span class="hide id">1262</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">61</span>
    <span class="hide fimg">top_frame_1262.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe">
                <img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1262.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <b>Code:</b> 130DO
        <br>
        <b>Color:</b> Mocha
        <br>
        <b>Material:</b> Wood
        <br>
        <b>Width:</b> 1.5 cm
        <br>
        <b>Height:</b> 2 cm
        <br>
        <b style="color: red;">Rate:</b> 2
        <br>
        <br>
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1262.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-4 code-130GO" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">130GO</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.5</span>
    <span class="hide frate">4</span>
    <span class="hide id">1267</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">61</span>
    <span class="hide fimg">top_frame_1267.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe">
                <img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1267.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <b>Code:</b> 130GO
        <br>
        <b>Color:</b> Grey
        <br>
        <b>Material:</b> Wood
        <br>
        <b>Width:</b> 1.5 cm
        <br>
        <b>Height:</b> 2 cm
        <br>
        <b style="color: red;">Rate:</b> 4
        <br>
        <br>
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1267.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-5 code-130NO" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">130NO</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.5</span>
    <span class="hide frate">5</span>
    <span class="hide id">1258</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">61</span>
    <span class="hide fimg">top_frame_1258.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe">
                <img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1258.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <b>Code:</b> 130NO
        <br>
        <b>Color:</b> Navy
        <br>
        <b>Material:</b> Wood
        <br>
        <b>Width:</b> 1.5 cm
        <br>
        <b>Height:</b> 2 cm
        <br>
        <b style="color: red;">Rate:</b> 5
        <br>
        <br>
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1258.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-6 code-130OO" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">130OO</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.5</span>
    <span class="hide frate">6</span>
    <span class="hide id">1259</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">61</span>
    <span class="hide fimg">top_frame_1259.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe">
                <img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1259.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <b>Code:</b> 130OO
        <br>
        <b>Color:</b> Orange
        <br>
        <b>Material:</b> Wood
        <br>
        <b>Width:</b> 1.5 cm
        <br>
        <b>Height:</b> 2 cm
        <br>
        <b style="color: red;">Rate:</b> 6
        <br>
        <br>
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1259.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-7 code-130PO" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">130PO</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.5</span>
    <span class="hide frate">7</span>
    <span class="hide id">1257</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">61</span>
    <span class="hide fimg">top_frame_1257.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe">
                <img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1257.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <b>Code:</b> 130PO
        <br>
        <b>Color:</b> Olive Pistachio
        <br>
        <b>Material:</b> Wood
        <br>
        <b>Width:</b> 1.5 cm
        <br>
        <b>Height:</b> 2 cm
        <br>
        <b style="color: red;">Rate:</b> 7
        <br>
        <br>
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1257.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-8 code-130RO" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">130RO</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.5</span>
    <span class="hide frate">8</span>
    <span class="hide id">1261</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">61</span>
    <span class="hide fimg">top_frame_1261.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe">
                <img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1261.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <b>Code:</b> 130RO
        <br>
        <b>Color:</b> Cherry
        <br>
        <b>Material:</b> Wood
        <br>
        <b>Width:</b> 1.5 cm
        <br>
        <b>Height:</b> 2 cm
        <br>
        <b style="color: red;">Rate:</b> 8
        <br>
        <br>
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1261.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-9 code-130TO" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">130TO</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.5</span>
    <span class="hide frate">9</span>
    <span class="hide id">1264</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">61</span>
    <span class="hide fimg">top_frame_1264.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe">
                <img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1264.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <b>Code:</b> 130TO
        <br>
        <b>Color:</b> Taupe
        <br>
        <b>Material:</b> Wood
        <br>
        <b>Width:</b> 1.5 cm
        <br>
        <b>Height:</b> 2 cm
        <br>
        <b style="color: red;">Rate:</b> 9
        <br>
        <br>
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1264.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-10 code-130YO" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">130YO</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.5</span>
    <span class="hide frate">10</span>
    <span class="hide id">1260</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">61</span>
    <span class="hide fimg">top_frame_1260.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe">
                <img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1260.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <b>Code:</b> 130YO
        <br>
        <b>Color:</b> Lemon
        <br>
        <b>Material:</b> Wood
        <br>
        <b>Width:</b> 1.5 cm
        <br>
        <b>Height:</b> 2 cm
        <br>
        <b style="color: red;">Rate:</b> 10
        <br>
        <br>
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1260.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>
<div class="frame" data-filtr="rate-2 code-133AQ" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;">
    <span class="hide code">133AQ</span>
    <span class="hide rebate">0.50</span>
    <span class="hide width">1.5</span>
    <span class="hide frate">2</span>
    <span class="hide id">1299</span>
    <span class="hide fmin">10</span>
    <span class="hide fmax">72</span>
    <span class="hide fimg">top_frame_1299.jpg</span>
    <div class="col">
        <strong>
            <a href="javascript: $('#size-notice').show();void(true);" class="selectframe">
                <img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1299.jpg" style="float: right; margin-right: 5px;" class="dropshadow">
            </a>
        </strong>
    </div>
    <div class="col" style="padding-left:5px">
        <b>Code:</b> 133AQ
        <br>
        <b>Color:</b> Aqua and Raw
        <br>
        <b>Material:</b> Wood
        <br>
        <b>Width:</b> 1.5 cm
        <br>
        <b>Height:</b> 3 cm
        <br>
        <b style="color: red;">Rate:</b> 2
        <br>
        <br>
        <strong>
            <a href="javascript: void(true);" class="selectframe">Select</a>
        </strong>
        <strong>
            <a href="images/frame_images/large/lrg_cross_frame_1299.jpg" class="zoom">zoom</a>
        </strong>
    </div>
</div>
<div style="clear: both;"></div>