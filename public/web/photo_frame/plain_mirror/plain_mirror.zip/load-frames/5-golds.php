    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">AL6Gold</span><span class="hide rebate">0.70</span><span class="hide width">1</span><span class="hide frate">5</span><span class="hide id">1269</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_1269.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1269.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> AL6Gold
            <br><b>Color:</b> Golg
            <br><b>Material:</b> Aluminium
            <br>
            <b>Width:</b> 1 cm
            <br>
            <b>Height:</b> 1 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1269.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">123G</span><span class="hide rebate">0.40</span><span class="hide width">1.5</span><span class="hide frate">5</span><span class="hide id">256</span><span class="hide fmin">10</span><span class="hide fmax">80</span><span class="hide fimg">top_frame_256.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_256.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 123G
            <br><b>Color:</b> Ornate Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.5 cm
            <br>
            <b>Height:</b> 1.8 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_256.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">133BR</span><span class="hide rebate">0.50</span><span class="hide width">1.5</span><span class="hide frate">6</span><span class="hide id">1296</span><span class="hide fmin">10</span><span class="hide fmax">72</span><span class="hide fimg">top_frame_1296.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1296.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 133BR
            <br><b>Color:</b> Bronze and Raw
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.5 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1296.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">249G</span><span class="hide rebate">0.50</span><span class="hide width">1.75</span><span class="hide frate">5</span><span class="hide id">1332</span><span class="hide fmin">10</span><span class="hide fmax">92</span><span class="hide fimg">top_frame_1332.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1332.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 249G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.75 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1332.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">414G</span><span class="hide rebate">0.50</span><span class="hide width">1.75</span><span class="hide frate">4</span><span class="hide id">1338</span><span class="hide fmin">10</span><span class="hide fmax">70</span><span class="hide fimg">top_frame_1338.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1338.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 414G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 1.75 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1338.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">155G</span><span class="hide rebate">0.50</span><span class="hide width">2</span><span class="hide frate">4</span><span class="hide id">1408</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_1408.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1408.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 155G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1408.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">217G</span><span class="hide rebate">0.50</span><span class="hide width">2</span><span class="hide frate">4</span><span class="hide id">1110</span><span class="hide fmin">9</span><span class="hide fmax">102</span><span class="hide fimg">top_frame_1110.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1110.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 217G
            <br><b>Color:</b> Gold aged
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1110.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">221G</span><span class="hide rebate">0.50</span><span class="hide width">2</span><span class="hide frate">4</span><span class="hide id">630</span><span class="hide fmin">10</span><span class="hide fmax">120</span><span class="hide fimg">top_frame_630.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_630.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 221G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_630.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">224G</span><span class="hide rebate">0.40</span><span class="hide width">2</span><span class="hide frate">3</span><span class="hide id">254</span><span class="hide fmin">10</span><span class="hide fmax">101</span><span class="hide fimg">top_frame_254.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_254.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 224G
            <br><b>Color:</b> Scratch Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_254.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">103G</span><span class="hide rebate">0.40</span><span class="hide width">2.1</span><span class="hide frate">5</span><span class="hide id">436</span><span class="hide fmin">10</span><span class="hide fmax">160</span><span class="hide fimg">top_frame_436.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_436.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 103G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.1 cm
            <br>
            <b>Height:</b> 3.8 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_436.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">156DG</span><span class="hide rebate">0.50</span><span class="hide width">2.25</span><span class="hide frate">4</span><span class="hide id">1383</span><span class="hide fmin">10</span><span class="hide fmax">102</span><span class="hide fimg">top_frame_1383.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1383.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 156DG
            <br><b>Color:</b> Dark Bronze and Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.25 cm
            <br>
            <b>Height:</b> 2.25 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1383.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">420G</span><span class="hide rebate">0.50</span><span class="hide width">2.25</span><span class="hide frate">4</span><span class="hide id">1386</span><span class="hide fmin">10</span><span class="hide fmax">102</span><span class="hide fimg">top_frame_1386.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1386.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 420G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.25 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1386.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">1201G</span><span class="hide rebate">0.50</span><span class="hide width">2.5</span><span class="hide frate">3</span><span class="hide id">1348</span><span class="hide fmin">10</span><span class="hide fmax">120</span><span class="hide fimg">top_frame_1348.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1348.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 1201G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.5 cm
            <br>
            <b>Height:</b> 2.25 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1348.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">122P</span><span class="hide rebate">0.50</span><span class="hide width">2.5</span><span class="hide frate">5</span><span class="hide id">822</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_822.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_822.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 122P
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.5 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_822.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">145G</span><span class="hide rebate">0.50</span><span class="hide width">2.5</span><span class="hide frate">5</span><span class="hide id">873</span><span class="hide fmin">10</span><span class="hide fmax">160</span><span class="hide fimg">top_frame_873.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_873.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 145G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.5 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_873.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">202G</span><span class="hide rebate">0.40</span><span class="hide width">2.5</span><span class="hide frate">6</span><span class="hide id">489</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_489.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_489.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 202G
            <br><b>Color:</b> Ornate White Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.5 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_489.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">214G</span><span class="hide rebate">0.50</span><span class="hide width">2.5</span><span class="hide frate">4</span><span class="hide id">1381</span><span class="hide fmin">10</span><span class="hide fmax">92</span><span class="hide fimg">top_frame_1381.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1381.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 214G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1381.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">401G</span><span class="hide rebate">0.50</span><span class="hide width">2.5</span><span class="hide frate">6</span><span class="hide id">1324</span><span class="hide fmin">10</span><span class="hide fmax">120</span><span class="hide fimg">top_frame_1324.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1324.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 401G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.5 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1324.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">426G</span><span class="hide rebate">0.50</span><span class="hide width">2.5</span><span class="hide frate">3</span><span class="hide id">1394</span><span class="hide fmin">10</span><span class="hide fmax">102</span><span class="hide fimg">top_frame_1394.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1394.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 426G
            <br><b>Color:</b> Gold Ornate
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.5 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1394.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">684G</span><span class="hide rebate">0.50</span><span class="hide width">2.75</span><span class="hide frate">8</span><span class="hide id">1211</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1211.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1211.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 684G
            <br><b>Color:</b> Bronze Black
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 2.75 cm
            <br>
            <b>Height:</b> 2.25 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1211.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">1002G</span><span class="hide rebate">0.50</span><span class="hide width">3</span><span class="hide frate">5</span><span class="hide id">1351</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1351.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1351.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 1002G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 5 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1351.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">195G</span><span class="hide rebate">0.50</span><span class="hide width">3</span><span class="hide frate">4</span><span class="hide id">1317</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_1317.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1317.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 195G
            <br><b>Color:</b> Antique Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1317.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">232G</span><span class="hide rebate">0.40</span><span class="hide width">3</span><span class="hide frate">4</span><span class="hide id">13</span><span class="hide fmin">10</span><span class="hide fmax">160</span><span class="hide fimg">top_frame_13.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_13.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 232G
            <br><b>Color:</b> Scratched Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_13.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">285G</span><span class="hide rebate">0.40</span><span class="hide width">3</span><span class="hide frate">2</span><span class="hide id">99</span><span class="hide fmin">10</span><span class="hide fmax">80</span><span class="hide fimg">top_frame_99.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_99.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 285G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Synthetic
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 2
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_99.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">286G</span><span class="hide rebate">0.50</span><span class="hide width">3</span><span class="hide frate">6</span><span class="hide id">948</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_948.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_948.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 286G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_948.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">624G</span><span class="hide rebate">0.50</span><span class="hide width">3</span><span class="hide frate">4</span><span class="hide id">663</span><span class="hide fmin">10</span><span class="hide fmax">120</span><span class="hide fimg">top_frame_663.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_663.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 624G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3 cm
            <br>
            <b>Height:</b> 2.2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_663.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">203B</span><span class="hide rebate">0.50</span><span class="hide width">3.25</span><span class="hide frate">4</span><span class="hide id">1045</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_1045.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1045.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 203B
            <br><b>Color:</b> Bronze
            <br><b>Material:</b> Synthetic
            <br>
            <b>Width:</b> 3.25 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1045.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">244G</span><span class="hide rebate">0.50</span><span class="hide width">3.25</span><span class="hide frate">8</span><span class="hide id">933</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_933.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_933.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 244G
            <br><b>Color:</b> Antique Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 3.25 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_933.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">268G</span><span class="hide rebate">0.50</span><span class="hide width">3.5</span><span class="hide frate">1</span><span class="hide id">762</span><span class="hide fmin">10</span><span class="hide fmax">80</span><span class="hide fimg">top_frame_762.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_762.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 268G
            <br><b>Color:</b> Scratch Gold
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 3.5 cm
            <br>
            <b>Height:</b> 1.5 cm
            <br>
            <b style="color: red;">Rate:</b> 1
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_762.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">1207G</span><span class="hide rebate">0.50</span><span class="hide width">4</span><span class="hide frate">8</span><span class="hide id">1350</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1350.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1350.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 1207G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1350.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">167P</span><span class="hide rebate">0.50</span><span class="hide width">4</span><span class="hide frate">4</span><span class="hide id">882</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_882.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_882.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 167P
            <br><b>Color:</b> Champagne
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_882.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">235G</span><span class="hide rebate">0.70</span><span class="hide width">4</span><span class="hide frate">4</span><span class="hide id">1032</span><span class="hide fmin">10</span><span class="hide fmax">80</span><span class="hide fimg">top_frame_1032.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1032.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 235G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 4 cm
            <br>
            <b>Height:</b> 2.8 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1032.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">349G</span><span class="hide rebate">0.50</span><span class="hide width">4</span><span class="hide frate">5</span><span class="hide id">969</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_969.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_969.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 349G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4 cm
            <br>
            <b>Height:</b> 2.75 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_969.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">349S</span><span class="hide rebate">0.50</span><span class="hide width">4</span><span class="hide frate">5</span><span class="hide id">968</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_968.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_968.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 349S
            <br><b>Color:</b> Gold Silver
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_968.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">408G</span><span class="hide rebate">0.50</span><span class="hide width">4</span><span class="hide frate">8</span><span class="hide id">1344</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1344.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1344.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 408G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1344.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">628G</span><span class="hide rebate">0.40</span><span class="hide width">4</span><span class="hide frate">8</span><span class="hide id">470</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_470.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_470.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 628G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4 cm
            <br>
            <b>Height:</b> 0 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_470.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">166G</span><span class="hide rebate">0.50</span><span class="hide width">4.25</span><span class="hide frate">6</span><span class="hide id">22</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_22.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_22.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 166G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.25 cm
            <br>
            <b>Height:</b> 2.6 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_22.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">179G</span><span class="hide rebate">0.50</span><span class="hide width">4.5</span><span class="hide frate">8</span><span class="hide id">719</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_719.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_719.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 179G
            <br><b>Color:</b> Antique Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_719.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">254G</span><span class="hide rebate">0.50</span><span class="hide width">4.5</span><span class="hide frate">3</span><span class="hide id">938</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_938.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_938.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 254G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_938.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">623G</span><span class="hide rebate">0.50</span><span class="hide width">4.5</span><span class="hide frate">5</span><span class="hide id">662</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_662.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_662.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 623G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 2.2 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_662.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">685G</span><span class="hide rebate">0.50</span><span class="hide width">4.5</span><span class="hide frate">12</span><span class="hide id">1210</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1210.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1210.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 685G
            <br><b>Color:</b> Bronze Black washed
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 4.5 cm
            <br>
            <b>Height:</b> 3.25 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1210.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">117G</span><span class="hide rebate">0.40</span><span class="hide width">5</span><span class="hide frate">5</span><span class="hide id">471</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_471.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_471.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 117G
            <br><b>Color:</b> Bronze Black
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_471.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">263G</span><span class="hide rebate">0.40</span><span class="hide width">5</span><span class="hide frate">3</span><span class="hide id">21</span><span class="hide fmin">10</span><span class="hide fmax">130</span><span class="hide fimg">top_frame_21.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_21.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 263G
            <br><b>Color:</b> Brushed Gold
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_21.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">516G</span><span class="hide rebate">0.50</span><span class="hide width">5.25</span><span class="hide frate">3</span><span class="hide id">830</span><span class="hide fmin">10</span><span class="hide fmax">120</span><span class="hide fimg">top_frame_830.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_830.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 516G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 5.25 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_830.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">272R</span><span class="hide rebate">0.40</span><span class="hide width">5.5</span><span class="hide frate">4</span><span class="hide id">138</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_138.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_138.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 272R
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 5.5 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_138.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">350G</span><span class="hide rebate">0.50</span><span class="hide width">5.5</span><span class="hide frate">8</span><span class="hide id">965</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_965.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_965.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 350G
            <br><b>Color:</b> Antique Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 5.5 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_965.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">627B</span><span class="hide rebate">0.40</span><span class="hide width">5.5</span><span class="hide frate">12</span><span class="hide id">483</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_483.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_483.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 627B
            <br><b>Color:</b> Dark Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 5.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_483.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">627W</span><span class="hide rebate">0.40</span><span class="hide width">5.5</span><span class="hide frate">12</span><span class="hide id">485</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_485.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_485.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 627W
            <br><b>Color:</b> Gold White
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 5.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_485.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">682G</span><span class="hide rebate">0.50</span><span class="hide width">5.5</span><span class="hide frate">8</span><span class="hide id">997</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_997.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_997.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 682G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 5.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_997.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">513G</span><span class="hide rebate">0.50</span><span class="hide width">6.25</span><span class="hide frate">16</span><span class="hide id">809</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_809.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_809.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 513G
            <br><b>Color:</b> Gold Leaf
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6.25 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 16
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_809.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">116G</span><span class="hide rebate">0.50</span><span class="hide width">6.5</span><span class="hide frate">6</span><span class="hide id">869</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_869.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_869.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 116G
            <br><b>Color:</b> Antique Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6.5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_869.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">600G</span><span class="hide rebate">0.50</span><span class="hide width">6.5</span><span class="hide frate">2</span><span class="hide id">1361</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_1361.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1361.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 600G
            <br><b>Color:</b> Pale Gold+Black
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6.5 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 2
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1361.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">636B</span><span class="hide rebate">0.50</span><span class="hide width">6.5</span><span class="hide frate">6</span><span class="hide id">839</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_839.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_839.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 636B
            <br><b>Color:</b> Bronze Antique
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6.5 cm
            <br>
            <b>Height:</b> 4 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_839.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">642G</span><span class="hide rebate">0.50</span><span class="hide width">6.5</span><span class="hide frate">8</span><span class="hide id">661</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_661.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_661.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 642G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 6.5 cm
            <br>
            <b>Height:</b> 2.8 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_661.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">615B</span><span class="hide rebate">0.50</span><span class="hide width">7</span><span class="hide frate">5</span><span class="hide id">1134</span><span class="hide fmin">9</span><span class="hide fmax">130</span><span class="hide fimg">top_frame_1134.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1134.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 615B
            <br><b>Color:</b> Gold-Silver
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 7 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1134.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">615R</span><span class="hide rebate">0.50</span><span class="hide width">7</span><span class="hide frate">5</span><span class="hide id">1135</span><span class="hide fmin">9</span><span class="hide fmax">130</span><span class="hide fimg">top_frame_1135.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1135.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 615R
            <br><b>Color:</b> Gold-Burgandy
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 7 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1135.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">539G</span><span class="hide rebate">0.50</span><span class="hide width">7.5</span><span class="hide frate">13</span><span class="hide id">1222</span><span class="hide fmin">10</span><span class="hide fmax">240</span><span class="hide fimg">top_frame_1222.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1222.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 539G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 7.5 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 13
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1222.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">587G</span><span class="hide rebate">0.40</span><span class="hide width">7.5</span><span class="hide frate">4</span><span class="hide id">36</span><span class="hide fmin">10</span><span class="hide fmax">130</span><span class="hide fimg">top_frame_36.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_36.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 587G
            <br><b>Color:</b> Bright Gold
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 7.5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_36.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">597G</span><span class="hide rebate">0.50</span><span class="hide width">7.5</span><span class="hide frate">4</span><span class="hide id">835</span><span class="hide fmin">10</span><span class="hide fmax">200</span><span class="hide fimg">top_frame_835.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_835.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 597G
            <br><b>Color:</b> Pebble Gold
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 7.5 cm
            <br>
            <b>Height:</b> 2.5 cm
            <br>
            <b style="color: red;">Rate:</b> 4
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_835.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">517G</span><span class="hide rebate">0.50</span><span class="hide width">8</span><span class="hide frate">6</span><span class="hide id">827</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_827.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_827.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 517G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 8 cm
            <br>
            <b>Height:</b> 4 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_827.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">556G</span><span class="hide rebate">0.50</span><span class="hide width">8</span><span class="hide frate">13</span><span class="hide id">1128</span><span class="hide fmin">9</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_1128.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1128.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 556G
            <br><b>Color:</b> Gold Ornate
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 8 cm
            <br>
            <b>Height:</b> 4 cm
            <br>
            <b style="color: red;">Rate:</b> 13
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1128.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">567CH</span><span class="hide rebate">0.50</span><span class="hide width">8</span><span class="hide frate">8</span><span class="hide id">710</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_710.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_710.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 567CH
            <br><b>Color:</b> Light Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 8 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_710.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">532G</span><span class="hide rebate">0.50</span><span class="hide width">8.5</span><span class="hide frate">6</span><span class="hide id">1137</span><span class="hide fmin">9</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1137.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1137.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 532G
            <br><b>Color:</b> Gold antique
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 8.5 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1137.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">109G</span><span class="hide rebate">0.40</span><span class="hide width">9</span><span class="hide frate">6</span><span class="hide id">508</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_508.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_508.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 109G
            <br><b>Color:</b> Gold Black
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 9 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_508.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">506G</span><span class="hide rebate">0.40</span><span class="hide width">9</span><span class="hide frate">10</span><span class="hide id">622</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_622.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_622.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 506G
            <br><b>Color:</b> Gold Antique
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 9 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 10
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_622.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">507G</span><span class="hide rebate">0.40</span><span class="hide width">9</span><span class="hide frate">15</span><span class="hide id">623</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_623.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_623.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 507G
            <br><b>Color:</b> Pale Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 9 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 15
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_623.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">591G</span><span class="hide rebate">0.40</span><span class="hide width">9</span><span class="hide frate">12</span><span class="hide id">656</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_656.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_656.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 591G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 9 cm
            <br>
            <b>Height:</b> 5.5 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_656.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">632G</span><span class="hide rebate">0.50</span><span class="hide width">9</span><span class="hide frate">7</span><span class="hide id">1071</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1071.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1071.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 632G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 9 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 7
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1071.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">657G</span><span class="hide rebate">0.50</span><span class="hide width">9</span><span class="hide frate">6</span><span class="hide id">1112</span><span class="hide fmin">9</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_1112.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1112.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 657G
            <br><b>Color:</b> Pewter Gold
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 9 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 6
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1112.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">504G</span><span class="hide rebate">0.40</span><span class="hide width">10</span><span class="hide frate">12</span><span class="hide id">479</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_479.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_479.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 504G
            <br><b>Color:</b> GOLD
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 10 cm
            <br>
            <b>Height:</b> 4 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_479.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">510G</span><span class="hide rebate">0.50</span><span class="hide width">10</span><span class="hide frate">10</span><span class="hide id">732</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_732.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_732.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 510G
            <br><b>Color:</b> Gold Antique
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 10 cm
            <br>
            <b>Height:</b> 4.5 cm
            <br>
            <b style="color: red;">Rate:</b> 10
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_732.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">540G-539G</span><span class="hide rebate">0.50</span><span class="hide width">10</span><span class="hide frate">20</span><span class="hide id">1063</span><span class="hide fmin">25</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_1063.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1063.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 540G-539G
            <br><b>Color:</b> Double Frame
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 10 cm
            <br>
            <b>Height:</b> 7.5 cm
            <br>
            <b style="color: red;">Rate:</b> 20
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1063.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">542G</span><span class="hide rebate">0.50</span><span class="hide width">10</span><span class="hide frate">8</span><span class="hide id">1053</span><span class="hide fmin">25</span><span class="hide fmax">240</span><span class="hide fimg">top_frame_1053.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1053.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 542G
            <br><b>Color:</b> Gold Antique
            <br><b>Material:</b> Hard Synthetic
            <br>
            <b>Width:</b> 10 cm
            <br>
            <b>Height:</b> 5 cm
            <br>
            <b style="color: red;">Rate:</b> 8
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1053.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">545G</span><span class="hide rebate">0.70</span><span class="hide width">10</span><span class="hide frate">14</span><span class="hide id">647</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_647.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_647.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 545G
            <br><b>Color:</b> Antique Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 10 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 14
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_647.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">580G</span><span class="hide rebate">0.50</span><span class="hide width">10</span><span class="hide frate">10</span><span class="hide id">1039</span><span class="hide fmin">10</span><span class="hide fmax">300</span><span class="hide fimg">top_frame_1039.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_1039.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 580G
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 10 cm
            <br>
            <b>Height:</b> 3.5 cm
            <br>
            <b style="color: red;">Rate:</b> 10
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_1039.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">528G</span><span class="hide rebate">1.00</span><span class="hide width">11</span><span class="hide frate">12</span><span class="hide id">469</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_469.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_469.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 528G
            <br><b>Color:</b> Antique Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 11 cm
            <br>
            <b>Height:</b> 4.5 cm
            <br>
            <b style="color: red;">Rate:</b> 12
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_469.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">598G</span><span class="hide rebate">0.40</span><span class="hide width">13</span><span class="hide frate">20</span><span class="hide id">525</span><span class="hide fmin">10</span><span class="hide fmax">250</span><span class="hide fimg">top_frame_525.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_525.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> 598G
            <br><b>Color:</b> Antique Gold
            <br><b>Material:</b> Wood
            <br>
            <b>Width:</b> 13 cm
            <br>
            <b>Height:</b> 3 cm
            <br>
            <b style="color: red;">Rate:</b> 20
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_525.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>*******************
    <p>*******************</p>