    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">AL-1Black</span><span class="hide rebate">0.70</span><span class="hide width">1</span><span class="hide frate">3</span><span class="hide id">331</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_331.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_331.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> AL-1Black
            <br><b>Color:</b> Black
            <br><b>Material:</b> Aluminium
            <br>
            <b>Width:</b> 1 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_331.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">AL-2White</span><span class="hide rebate">0.70</span><span class="hide width">1</span><span class="hide frate">3</span><span class="hide id">330</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_330.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_330.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> AL-2White
            <br><b>Color:</b> White
            <br><b>Material:</b> Aluminium
            <br>
            <b>Width:</b> 1 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_330.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">AL-5Pink</span><span class="hide rebate">0.70</span><span class="hide width">1</span><span class="hide frate">3</span><span class="hide id">334</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_334.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_334.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> AL-5Pink
            <br><b>Color:</b> Pink
            <br><b>Material:</b> Aluminium
            <br>
            <b>Width:</b> 1 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 3
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_334.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">AL-6Gold</span><span class="hide rebate">0.70</span><span class="hide width">1</span><span class="hide frate">5</span><span class="hide id">335</span><span class="hide fmin">10</span><span class="hide fmax">100</span><span class="hide fimg">top_frame_335.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_335.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> AL-6Gold
            <br><b>Color:</b> Gold
            <br><b>Material:</b> Aluminium
            <br>
            <b>Width:</b> 1 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_335.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="frame" style="text-align: left; margin-bottom: 10px;border-bottom:1px dotted #ccc; min-height: 155px;"><span class="hide code">AL-7Silver</span><span class="hide rebate">0.70</span><span class="hide width">1</span><span class="hide frate">5</span><span class="hide id">336</span><span class="hide fmin">10</span><span class="hide fmax">150</span><span class="hide fimg">top_frame_336.jpg</span>
        <div class="col"><strong><a href="javascript: $('#size-notice').show();void(true);" class="selectframe"><img border="0" alt="" src="images/frame_images/thumb/th_cross_frame_336.jpg" style="float: right; margin-right: 5px;" class="dropshadow"></a></strong></div>
        <div class="col" style="padding-left:5px">
            <b>Code:</b> AL-7Silver
            <br><b>Color:</b> Silver
            <br><b>Material:</b> Aluminium
            <br>
            <b>Width:</b> 1 cm
            <br>
            <b>Height:</b> 2 cm
            <br>
            <b style="color: red;">Rate:</b> 5
            <br>
            <br>
            <strong><a href="javascript: void(true);" class="selectframe">Select</a></strong> <strong><a href="images/frame_images/large/lrg_cross_frame_336.jpg" class="zoom">zoom</a></strong>
        </div>
    </div>
    <div style="clear: both;"></div>*******************
    <p>*******************</p>